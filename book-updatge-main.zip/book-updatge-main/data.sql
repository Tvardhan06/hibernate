INSERT INTO books (book_id, title, author, genre, price, published_year) 
VALUES (1, 'Spring Boot in Action', 'Craig Walls', 'Technology', 45.99, 2016);

INSERT INTO books (book_id, title, author, genre, price, published_year) 
VALUES (2, 'Clean Code', 'Robert Martin', 'Technology', 50.00, 2008);
